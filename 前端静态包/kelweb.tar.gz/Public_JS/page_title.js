$(document).ready(function () {
  const model = $.cookie("model");
  if (model === 'KEEL-M13') {
    document.title = 'Keel'
  } else {
    document.title = 'Keel'
  }
});