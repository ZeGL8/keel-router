/*
 * kelargs.js —— 前端参数归一垫片（自动生成，请勿手改）
 *
 * 生成器：Keel/部署工具/生成前端垫片.py
 * 依据  ：后端插件 ARGS_DECL
 *
 * ubus 的参数类型是严格的，String 收数字、Integer 收字符串都会
 * Invalid argument；多传一个未声明的键也会被拒。原厂前端是压缩代码，
 * 同一个键在不同页面可能是 .val()（字符串）也可能是 parseInt()（数字）。
 * 本垫片在 XHR 发出前按声明统一归一，把这类问题一次性摁死。
 *
 * 附带好处：遇到未声明的参数键会 console.error 报出来，
 * 把「静默失败」变成「看得见的错」。
 */
(function () {
	'use strict';
	if (typeof XMLHttpRequest === 'undefined') return;
	if (XMLHttpRequest.prototype.__kelargs) return;

	/* 方法 → { 键: 's'(String) | 'i'(Integer) | 'a'(Array) | 't'(Table) } */
	var DECL = {
		"del_port_forward": { "name":'s' },

		"get_wifi_info": { "type":'i' },
		"guide_set_wifi": { "channel":'s', "enable":'s', "encryption":'s', "hidden":'s', "htmode":'s', "key":'s', "ssid":'s', "txpower":'s', "type":'i' },
		"mac_clone": { "macaddr":'s' },
		"mwan_get_interface_info": { "interface":'s' },
		"mwan_get_interface_status": { "interface":'s' },
		"mwan_set_interface_info": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "gateway":'s', "interface":'s', "ipaddr":'s', "mtu":'i', "mwm_pppoe_amount":'i', "mwm_pppoe_parallel":'i', "mwm_pppoe_switch":'i', "netmask":'s', "password":'s', "proto":'s', "username":'s' },
		"mwan_set_interface_type": { "interface":'s' },
		"mwan_set_switch": { "enable":'i' },

		"set_dmz": { "ipaddr":'s', "on_off":'i' },

		"set_game_info": { "enable":'s', "port":'s' },
		"set_hostname": { "hostname":'s' },
		"set_initialization_complete": { "sys_passwd":'s' },

		"set_lan_dhcp": { "dns1":'s', "dns2":'s', "enable":'s', "end":'s', "gateway":'s', "leasetime":'s', "start":'s' },
		"set_lan_dhcp_expand": { "dns1":'s', "dns2":'s', "enable":'s', "end":'a', "gateway":'s', "leasetime":'s', "start":'a' },
		"set_lan_ip": { "ipaddr":'s', "netmask":'s' },
		"set_login_passwd": { "confirm":'s', "new":'s', "old":'s' },
		"set_macfilter": { "enable":'s', "list":'a', "macpolicy":'s' },

		"set_nat_type": { "type":'s' },
		"set_port_forward": { "dest-port":'s', "edit":'s', "ipaddr":'s', "name":'s', "on-off":'i', "proto":'s', "src-dport":'s' },
		"set_router_wan_ifname": { "ifname":'s' },
		"set_upnp": { "enabled":'i' },
		"set_wan_dhcp": { "dns1":'s', "dns2":'s' },
		"set_wan_pppoe": { "dns":'s', "dns1":'s', "dns2":'s', "mtu":'i', "password":'s', "username":'s' },
		"set_wan_static": { "dns1":'s', "dns2":'s', "gateway":'s', "ipaddr":'s', "netmask":'s' },
		"set_wifi": { "channel":'s', "enable":'s', "encryption":'s', "hidden":'s', "htmode":'s', "key":'s', "ssid":'s', "txpower":'s', "type":'i' },
		"set_wifi_freq_mode": { "mode":'i' },
		"set_wifi_samessid": { "radio_2g":'t', "radio_52g":'t', "radio_5g":'t', "samessid":'t' },
		"set_wolink_enable": { "enabled":'i' },
		"web_config_ddns": { "action":'i', "check_interval":'s', "ddns_name":'s', "domain":'s', "force_interval":'s', "passwd":'s', "service":'s', "username":'s' },
		"web_del_dhcp_static_ip": { "ip":'s', "mac":'s', "name":'s' },
		"web_get_ddns": { "ddns_name":'s' },
		"web_get_ddns_uptime": { "ddns_name":'s' },
		"web_guide_set_wds_config": { "channel":'s', "enable":'i', "encryption":'s', "key":'s', "rssi":'s', "ssid":'s' },
		"web_set_credit_mode": { "mode":'i' },
		"web_set_custom_hosts": { "hosts":'s' },
		"web_set_device_limit_speed": { "download":'s', "enable":'s', "uid":'s', "upload":'s' },
		"web_set_dhcp_static_ip": { "ip":'s', "mac":'s', "name":'s' },
		"web_set_dual_frequency_optimization": { "enable":'s' },
		"web_set_guest_limit_speed": { "download":'s', "enable":'s', "upload":'s' },
		"web_set_ipv6_dhcpv6": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_nat6": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_native": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_onlyrouter": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_relay": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_slacc": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_ipv6_static": { "dns1":'s', "dns2":'s', "dns_enabled":'i', "enabled":'i', "fw_enable":'i', "lan_prefix":'s', "lan_prefix_len":'i', "type":'s', "wan_gateway":'s', "wan_ipaddr":'s' },
		"web_set_router_mode": { "mode":'i' },
		"web_set_station_name": { "name":'s', "uid":'s' },
		"web_set_wds_config": { "channel":'s', "enable":'i', "encryption":'s', "key":'s', "ssid":'s' },
		"web_set_wifi6_80211ax": { "band":'i', "enabled":'i' },
		"web_switch_ddns_service": { "action":'i', "ddns_name":'s' }
	};

	function coerce(v, t) {
		switch (t) {
		case 's':
			if (v === null || v === undefined) return '';
			if (typeof v === 'object') { try { return JSON.stringify(v); } catch (e) { return ''; } }
			return '' + v;
		case 'i':
			if (typeof v === 'boolean') return v ? 1 : 0;
			var n = Number(v);
			if (!isFinite(n)) return 0;
			return n < 0 ? Math.ceil(n) : Math.floor(n);
		case 'a':
			return Array.isArray(v) ? v : (v === null || v === undefined ? [] : [ v ]);
		case 't':
			if (v && typeof v === 'object') return v;
			return {};
		}
		return v;
	}

	function normalize(o) {
		if (!o || typeof o !== 'object' || o instanceof Array) return o;
		var p = o.params;
		if (!p || p.length < 4 || p[1] !== 'kelapi.static') return o;
		var spec = DECL[p[2]];
		if (!spec) return o;

		var src = p[3];
		if (src === null || src === undefined || typeof src !== 'object' || src instanceof Array) return o;

		var out = {}, k;
		for (k in src) {
			if (!Object.prototype.hasOwnProperty.call(src, k)) continue;
			if (!Object.prototype.hasOwnProperty.call(spec, k)) {
				/* 后端没声明这个键 —— 原样发过去必然 Invalid argument，
				   丢掉并报错，免得变成一个查不出的静默失败 */
				if (typeof console !== 'undefined' && console.error)
					console.error('[kelargs] 后端未声明参数 ' + p[2] + '.' + k + '，已丢弃。请补进 ARGS_DECL。', src[k]);
				continue;
			}
			out[k] = coerce(src[k], spec[k]);
		}
		p[3] = out;
		return o;
	}

	var send = XMLHttpRequest.prototype.send;
	XMLHttpRequest.prototype.send = function (body) {
		if (typeof body === 'string' && body.length && body.charCodeAt(0) === 123 /* '{' */) {
			try {
				var o = JSON.parse(body);
				var n = normalize(o);
				if (n !== o || true) body = JSON.stringify(n);
			} catch (e) {
				if (typeof console !== 'undefined' && console.error)
					console.error('[kelargs] 解析请求体失败', e);
			}
		}
		return send.call(this, body);
	};
	XMLHttpRequest.prototype.__kelargs = 1;
})();
